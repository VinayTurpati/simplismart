def test_hello_world():
    assert True

def test_scheduling():
    assert True